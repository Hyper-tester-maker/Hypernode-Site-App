# Hypernode Bridge

**Cross-Chain Bridge Between Solana and Base**

Enable HYPER token and job payments across Solana and Base blockchain.

![Solana](https://img.shields.io/badge/Solana-Mainnet-blueviolet)
![Base](https://img.shields.io/badge/Base-Mainnet-blue)
![Solidity](https://img.shields.io/badge/Solidity-0.8.20-gray)

---

## 🎯 Overview

The Hypernode Bridge enables:
- Lock HYPER on Solana → Mint wrapped HYPER on Base
- Burn wrapped HYPER on Base → Unlock HYPER on Solana
- Submit jobs from Base chain
- Cross-chain payment settlement

---

## ✨ Features

- ✅ **Trustless Bridge**: No centralized custodian
- ✅ **Fast Transfers**: <5 minute finality
- ✅ **Low Fees**: Optimized for gas efficiency
- ✅ **Multi-sig Security**: 5/9 validator threshold
- ✅ **Event Monitoring**: Real-time cross-chain sync
- ✅ **Relayer Network**: Decentralized message passing

---

## 🏗️ Architecture

```
Solana                      Base
┌──────────────┐           ┌──────────────┐
│ HYPER Token  │           │ wHYPER Token │
│ (SPL)        │           │ (ERC-20)     │
└───────┬──────┘           └──────┬───────┘
        │                         │
        │  Lock HYPER             │
        ▼                         │
┌──────────────┐                 │
│ Bridge       │                 │
│ Program      │   ◄─Relayers─►  │
│ (Anchor)     │                 │
└───────┬──────┘                 │
        │                         │
        │                         ▼
        │                  ┌──────────────┐
        │                  │ Bridge       │
        └──────────────────┤ Contract     │
                           │ (Solidity)   │
                           └──────────────┘
```

---

## 🚀 Quick Start

### Bridge HYPER from Solana to Base

```typescript
import { bridgeToBase } from '@hypernode/bridge';

await bridgeToBase({
  amount: 1000, // HYPER tokens
  destinationAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb',
  walletAdapter: phantomWallet
});
```

### Bridge wHYPER from Base to Solana

```typescript
import { bridgeToSolana } from '@hypernode/bridge';

await bridgeToSolana({
  amount: 1000, // wHYPER tokens
  destinationAddress: 'YourSolanaPublicKey...',
  signer: metamaskSigner
});
```

---

## 📁 Project Structure

```
hypernode-bridge/
├── solana/                  # Solana bridge program (Anchor)
│   ├── programs/
│   │   └── bridge/
│   │       └── src/
│   │           ├── lib.rs
│   │           └── instructions/
│   ├── Anchor.toml
│   └── Cargo.toml
│
├── base/                    # Base smart contracts (Solidity)
│   ├── contracts/
│   │   ├── HypernodeBridge.sol
│   │   └── WrappedHYPER.sol
│   ├── hardhat.config.ts
│   └── package.json
│
├── relayer/                 # Off-chain relayer (Node.js)
│   ├── src/
│   │   ├── solana-listener.ts
│   │   ├── base-listener.ts
│   │   └── message-relay.ts
│   └── package.json
│
└── README.md
```

---

## 🔐 Security

### Multi-sig Validators
- 9 independent validators
- 5/9 threshold for message validation
- No single point of failure

### Audits
- [ ] Solana program audit (pending)
- [ ] Base contract audit (pending)
- [ ] Relayer security review (pending)

---

## 💰 Fees

- **Solana → Base**: 0.1% bridge fee + Solana tx fee
- **Base → Solana**: 0.1% bridge fee + Base gas fee
- **Relayer costs**: Covered by protocol

---

## 📚 Resources

- [Solana Program](./solana/)
- [Base Contracts](./base/)
- [Relayer Documentation](./relayer/)

---

## 📄 License

MIT License

---

**Bridge assets seamlessly across chains! 🌉**
