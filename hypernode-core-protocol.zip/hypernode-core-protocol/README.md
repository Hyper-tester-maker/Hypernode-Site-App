# Hypernode Core Protocol

**Solana Smart Contracts for Hypernode Distributed GPU Network**

This repository contains the on-chain programs (smart contracts) that power the Hypernode network on Solana.

![Solana](https://img.shields.io/badge/Blockchain-Solana-blueviolet)
![Anchor](https://img.shields.io/badge/Framework-Anchor-orange)
![Rust](https://img.shields.io/badge/Language-Rust-red)

---

## 🎯 Overview

The Hypernode Core Protocol consists of Solana programs that handle:
- **Node Registry**: Register and manage GPU/CPU nodes on-chain
- **Job Receipts**: Create immutable job execution records
- **Payment Distribution**: Split payments between operators, treasury, and pools
- **Bridge Adapter**: Cross-chain functionality (optional)

All critical operations are recorded on-chain for transparency and auditability.

---

## 📦 Programs

### 1. Node Registry Program
**Purpose**: Register, update, and manage compute nodes on-chain

**Instructions**:
- `register_node`: Register a new GPU/CPU node
- `update_node_status`: Update node status (online/offline)
- `stake_for_node`: Stake HYPER tokens for reputation
- `deregister_node`: Remove node from registry

**Accounts**:
```rust
pub struct NodeAccount {
    pub owner: Pubkey,              // Node operator wallet
    pub node_id: String,            // Unique node identifier
    pub gpu_specs_hash: String,     // Hash of GPU specifications
    pub registered_at: i64,         // Unix timestamp
    pub last_heartbeat: i64,        // Last activity timestamp
    pub status: NodeStatus,         // online, offline, suspended
    pub stake_amount: u64,          // Staked HYPER (in lamports)
    pub reputation_score: u16,      // 0-1000
    pub jobs_completed: u64,        // Total jobs executed
    pub total_earned: u64,          // Total HYPER earned
}

pub enum NodeStatus {
    Online,
    Offline,
    Suspended,
}
```

---

### 2. Job Receipt Program
**Purpose**: Create immutable records of job execution and results

**Instructions**:
- `create_job`: Create job request on-chain
- `assign_job`: Assign job to a node
- `submit_result`: Node submits job completion proof
- `settle_job`: Finalize payment distribution

**Accounts**:
```rust
pub struct JobAccount {
    pub job_id: String,             // Unique job identifier
    pub client: Pubkey,             // Job requester wallet
    pub assigned_node: Option<Pubkey>, // Assigned node operator
    pub job_type: JobType,          // Type of computation
    pub price: u64,                 // Job price in HYPER
    pub created_at: i64,            // Creation timestamp
    pub completed_at: Option<i64>,  // Completion timestamp
    pub status: JobStatus,          // Status of job
    pub result_hash: Option<String>, // Hash of job result
    pub payment_settled: bool,      // Payment distributed
}

pub enum JobType {
    LlmInference,
    LlmFineTuning,
    RagIndexing,
    VisionPipeline,
    Render,
    GenericCompute,
}

pub enum JobStatus {
    Pending,
    Assigned,
    Running,
    Completed,
    Failed,
    Cancelled,
}
```

---

### 3. Payment Splitter Program
**Purpose**: Distribute HYPER payments among stakeholders

**Instructions**:
- `initialize_splitter`: Setup payment distribution rules
- `process_payment`: Split payment for completed job
- `withdraw_treasury`: Treasury withdrawal (governance)

**Distribution**:
- **80%** → Node operator
- **10%** → Protocol treasury
- **5%** → Incentive pool
- **5%** → Orchestrator/Agent (if applicable)

**Accounts**:
```rust
pub struct PaymentSplitter {
    pub authority: Pubkey,          // Program authority
    pub treasury: Pubkey,           // Treasury wallet
    pub incentive_pool: Pubkey,     // Incentive pool wallet
    pub operator_share: u8,         // 80 (percentage)
    pub treasury_share: u8,         // 10
    pub incentive_share: u8,        // 5
    pub orchestrator_share: u8,     // 5
}
```

---

### 4. Bridge Adapter Program (Optional)
**Purpose**: Enable cross-chain interactions with Base blockchain

**Instructions**:
- `lock_tokens`: Lock HYPER on Solana
- `mint_wrapped`: Mint wrapped HYPER on Base
- `burn_wrapped`: Burn wrapped HYPER
- `unlock_tokens`: Unlock HYPER on Solana

---

## 🏗️ Architecture

```
Client/App
    │
    ▼
┌─────────────────────────────────────────┐
│   Hypernode Core Protocol (On-Chain)   │
├─────────────────────────────────────────┤
│                                         │
│  ┌──────────────────┐                  │
│  │ Node Registry    │                  │
│  │ Program          │◄─────────────────┼──── register_node()
│  └────────┬─────────┘                  │
│           │                             │
│           │ emits event                 │
│           ▼                             │
│  ┌──────────────────┐                  │
│  │ Job Receipt      │                  │
│  │ Program          │◄─────────────────┼──── create_job()
│  └────────┬─────────┘                  │
│           │                             │
│           │ triggers                    │
│           ▼                             │
│  ┌──────────────────┐                  │
│  │ Payment Splitter │                  │
│  │ Program          │◄─────────────────┼──── settle_job()
│  └──────────────────┘                  │
│                                         │
└─────────────────────────────────────────┘
         │
         ▼
    Solana Blockchain
    (Immutable Ledger)
```

---

## 🛠️ Tech Stack

- **Framework**: [Anchor](https://www.anchor-lang.com/) v0.29+
- **Language**: Rust
- **Blockchain**: Solana (Mainnet/Devnet)
- **Testing**: Anchor Test Suite (Mocha/Chai)
- **Deployment**: Solana CLI

---

## 📁 Project Structure

```
hypernode-core-protocol/
├── programs/
│   ├── node-registry/         # Node registration program
│   │   └── src/
│   │       ├── lib.rs         # Program entrypoint
│   │       ├── instructions/  # Program instructions
│   │       ├── state/         # Account structures
│   │       └── errors.rs      # Custom errors
│   │
│   ├── job-receipt/           # Job receipt program
│   │   └── src/
│   │       ├── lib.rs
│   │       ├── instructions/
│   │       ├── state/
│   │       └── errors.rs
│   │
│   ├── payment-splitter/      # Payment distribution program
│   │   └── src/
│   │       ├── lib.rs
│   │       ├── instructions/
│   │       ├── state/
│   │       └── errors.rs
│   │
│   └── bridge-adapter/        # Cross-chain bridge (optional)
│       └── src/
│           ├── lib.rs
│           └── ...
│
├── tests/                     # Integration tests
│   ├── node-registry.test.ts
│   ├── job-receipt.test.ts
│   └── payment-splitter.test.ts
│
├── scripts/                   # Deployment scripts
│   ├── deploy-devnet.sh
│   └── deploy-mainnet.sh
│
├── migrations/
│   └── deploy.ts
│
├── Anchor.toml               # Anchor configuration
├── Cargo.toml                # Rust workspace
├── package.json              # Node dependencies
└── README.md                 # This file
```

---

## 🚀 Quick Start

### Prerequisites

- Rust 1.70+
- Solana CLI 1.17+
- Anchor CLI 0.29+
- Node.js 18+
- Yarn or npm

### Installation

```bash
# Clone repository
git clone https://github.com/your-org/hypernode-core-protocol.git
cd hypernode-core-protocol

# Install Anchor (if not installed)
cargo install --git https://github.com/coral-xyz/anchor avm --locked --force
avm install latest
avm use latest

# Install dependencies
yarn install
# or
npm install

# Build programs
anchor build

# Run tests
anchor test
```

---

## 🧪 Testing

### Run all tests
```bash
anchor test
```

### Run specific test
```bash
anchor test -- --grep "register_node"
```

### Test on Devnet
```bash
anchor test --provider.cluster devnet
```

---

## 🚢 Deployment

### Deploy to Devnet
```bash
# Set Solana config to devnet
solana config set --url devnet

# Airdrop SOL for deployment (if needed)
solana airdrop 2

# Deploy programs
anchor deploy

# Or use script
./scripts/deploy-devnet.sh
```

### Deploy to Mainnet
```bash
# Set Solana config to mainnet
solana config set --url mainnet-beta

# Deploy programs (ensure you have enough SOL)
anchor deploy

# Or use script
./scripts/deploy-mainnet.sh
```

### Get Program IDs
```bash
solana address -k target/deploy/node_registry-keypair.json
solana address -k target/deploy/job_receipt-keypair.json
solana address -k target/deploy/payment_splitter-keypair.json
```

---

## 📝 Program Instructions

### Node Registry

**Register Node**:
```typescript
await program.methods
  .registerNode(nodeId, gpuSpecsHash, location)
  .accounts({
    nodeAccount,
    owner: wallet.publicKey,
    systemProgram: SystemProgram.programId,
  })
  .rpc();
```

**Update Status**:
```typescript
await program.methods
  .updateNodeStatus(NodeStatus.Online)
  .accounts({
    nodeAccount,
    owner: wallet.publicKey,
  })
  .rpc();
```

**Stake for Node**:
```typescript
await program.methods
  .stakeForNode(stakeAmount)
  .accounts({
    nodeAccount,
    owner: wallet.publicKey,
    tokenAccount,
    hyperMint,
    tokenProgram: TOKEN_PROGRAM_ID,
  })
  .rpc();
```

---

### Job Receipt

**Create Job**:
```typescript
await program.methods
  .createJob(jobId, jobType, price, requirementsHash)
  .accounts({
    jobAccount,
    client: wallet.publicKey,
    systemProgram: SystemProgram.programId,
  })
  .rpc();
```

**Submit Result**:
```typescript
await program.methods
  .submitResult(jobId, resultHash, logsUrl)
  .accounts({
    jobAccount,
    nodeAccount,
    operator: wallet.publicKey,
  })
  .rpc();
```

**Settle Job**:
```typescript
await program.methods
  .settleJob()
  .accounts({
    jobAccount,
    paymentSplitter,
    client,
    operator,
    treasury,
    incentivePool,
    tokenProgram: TOKEN_PROGRAM_ID,
  })
  .rpc();
```

---

## 🔐 Security

### Audits
- [ ] Internal security review
- [ ] External audit (pending)
- [ ] Bug bounty program (post-launch)

### Best Practices
- All accounts are PDA-based for security
- Owner validation on all state-changing instructions
- Arithmetic overflow protection
- Reentrancy guards where applicable

---

## 📊 Events

Programs emit events for off-chain indexing:

```rust
#[event]
pub struct NodeRegistered {
    pub node_id: String,
    pub owner: Pubkey,
    pub timestamp: i64,
}

#[event]
pub struct JobCreated {
    pub job_id: String,
    pub client: Pubkey,
    pub price: u64,
    pub timestamp: i64,
}

#[event]
pub struct JobCompleted {
    pub job_id: String,
    pub operator: Pubkey,
    pub result_hash: String,
    pub timestamp: i64,
}

#[event]
pub struct PaymentDistributed {
    pub job_id: String,
    pub operator_amount: u64,
    pub treasury_amount: u64,
    pub timestamp: i64,
}
```

---

## 🔗 Integration

### With hypernode-app
The web app calls these programs via `@solana/web3.js`:
```typescript
import { Program, AnchorProvider } from '@coral-xyz/anchor';
import { NodeRegistryIDL } from './idls/node_registry';

const program = new Program(NodeRegistryIDL, programId, provider);
```

### With hypernode-automation-engine
The HAE listens to program events:
```typescript
connection.onLogs(programId, (logs) => {
  // Process NodeRegistered, JobCreated events
});
```

---

## 📚 Resources

- [Anchor Documentation](https://www.anchor-lang.com/)
- [Solana Cookbook](https://solanacookbook.com/)
- [Solana Program Library](https://spl.solana.com/)
- [Hypernode Architecture](../ARCHITECTURE.md)

---

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/program-xyz`)
3. Write tests for new instructions
4. Commit your changes (`git commit -m 'Add program xyz'`)
5. Push to the branch (`git push origin feature/program-xyz`)
6. Open a Pull Request

---

## 📄 License

MIT License - see LICENSE file for details

---

## 🆘 Support

- GitHub Issues: [Report bugs](https://github.com/your-org/hypernode-core-protocol/issues)
- Discord: [Join community](https://discord.gg/hypernode)
- Docs: [Read documentation](https://docs.hypernode.sol)

---

**Built with ❤️ on Solana**
